package com.testhere.a;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter{
	 @Override
	 protected void configure(HttpSecurity http) throws Exception {
	        http
	            // ... your security configuration ...

	            // Session management
	            .sessionManagement()
	                .maximumSessions(1)
	                .maxSessionsPreventsLogin(true) // Optional
	                .sessionRegistry(sessionRegistry());
	    }

	    @Bean
	    public SessionRegistry sessionRegistry() {
	        return new SessionRegistryImpl();
	    }
}
