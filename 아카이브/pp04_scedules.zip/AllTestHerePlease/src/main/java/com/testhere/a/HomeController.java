package com.testhere.a;

import java.text.DateFormat;
import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ScheduledFuture;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.TaskScheduler;

import org.springframework.scheduling.annotation.Scheduled;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	public int testN = 0;
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	 private TaskScheduler taskScheduler;  // TaskScheduler field
	 private ScheduledFuture<?> scheduledTask;
	 private volatile boolean shouldRunScheduledTask = true;
	    @Autowired
	    public void setTaskScheduler(TaskScheduler taskScheduler) {
	        this.taskScheduler = taskScheduler;
	    }
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model, HttpSession session) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		TestVO testvo = new TestVO();
		testvo.setNames("abc");
		testvo.setNumbers(132);
		List<TestVO> volist = new ArrayList<>();
		volist.add(testvo);
		volist.add(testvo);
		
		String formattedDate = dateFormat.format(date);
		session.setAttribute("name", testvo);
		session.setAttribute("lists", volist);
		session.setMaxInactiveInterval(10);
		model.addAttribute("serverTime", formattedDate );
		
		return "home";
	}
	
	
//	public void testSc() {
//		testN ++;
//		System.out.println("test");
//		System.out.println(testN);
//	}
//
	 @Scheduled(fixedRate = 1000)
	    public void testSc() {
	        if (shouldRunScheduledTask) {
	            testN++;
	            System.out.println("test");
	            System.out.println(testN);

	            if (testN >= 10) {
	                // If testN is 100 or more, stop the scheduled task
	                shouldRunScheduledTask = false;
	                System.out.println("Stopping the scheduled task.");
	                stopScheduledTask();
	            }
	        }else {
	        	System.out.println("you should not read this error... please");
	        }
	    }
	 public void stopScheduledTask() {
	        if (scheduledTask != null && !scheduledTask.isDone()) {
	            scheduledTask.cancel(true);
	        }
	    }
	 
}
