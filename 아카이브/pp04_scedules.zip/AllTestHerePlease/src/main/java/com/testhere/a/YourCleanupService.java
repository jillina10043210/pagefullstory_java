package com.testhere.a;

import org.springframework.stereotype.Service;
import javax.servlet.http.HttpSession;

@Service
public class YourCleanupService {

    public void performCleanup(HttpSession session) {
        // Add your custom cleanup logic here
        // This method will be called when a session is destroyed
    	System.out.println("service activated!");
        // Example: Invalidate the session to release associated resources
        session.invalidate();
        
        // You can add more custom cleanup tasks as needed
        // For instance, close database connections, release resources, etc.
    }
    public void performCleanup2(HttpSession session) {
        // Add your custom cleanup logic here
        // This method will be called when a session is destroyed
    	System.out.println("service2 activated!");
        // Example: Invalidate the session to release associated resources
        session.invalidate();
        
        // You can add more custom cleanup tasks as needed
        // For instance, close database connections, release resources, etc.
    }
    
}
