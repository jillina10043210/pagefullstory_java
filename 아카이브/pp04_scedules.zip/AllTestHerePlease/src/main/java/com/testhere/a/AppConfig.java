package com.testhere.a;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;

@Configuration
@ComponentScan("com.testhere.a")
@ImportResource("classpath:/WEB-INF/scheduling-config.xml")
public class AppConfig {

}
