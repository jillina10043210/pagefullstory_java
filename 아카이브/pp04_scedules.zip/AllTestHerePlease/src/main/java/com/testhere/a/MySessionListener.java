package com.testhere.a;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.scheduling.annotation.Scheduled;

@Component
public class MySessionListener implements HttpSessionListener {
	 
	@Autowired
    private YourCleanupService cleanupService;
	
	@Override
	public void sessionCreated(HttpSessionEvent se) {
		// TODO Auto-generated method stub
		
		System.out.println("created");
		
	}

	@Override
	public void sessionDestroyed(HttpSessionEvent se) {
		
		System.out.println("service activated333");
        // Perform cleanup tasks when the session is invalidated
		

	}
	
}
