package com.ajar.interceptor;

import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.HandlerInterceptor;



public class Interceptor implements HandlerInterceptor {
	 
	List<String> allowedPaths = Arrays.asList("/interceptor/test/qwe","/interceptor/test/def");

	   

	    @Override
	    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
	        String requestPath = request.getRequestURI();

	        // Check if the request path matches any allowed paths
	        for (String allowedPath : allowedPaths) {
	            if (allowedPath.equals(requestPath) && "GET".equals(request.getMethod())) {
	                // If the request path matches the allowed path and the method is GET,
	                // perform interceptor logic here (if needed)
	                  // Continue processing the request
	            	response.sendRedirect(request.getContextPath() + "/fail");
	    	        return false;
	            }
	        }

	        // If the request path does not match the allowed path or the method is not GET,
	        // redirect to "/fail"
	        
	        return true;
	    }
}
