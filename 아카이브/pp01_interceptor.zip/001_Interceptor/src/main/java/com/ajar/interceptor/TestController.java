package com.ajar.interceptor;

import java.util.Locale;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/test")
public class TestController {
	
	@RequestMapping(value = "/abc", method = {RequestMethod.GET, RequestMethod.POST})
	public String abc(Locale locale, Model model) {
		return "abc";
	}
	@RequestMapping(value = "/def", method = {RequestMethod.GET, RequestMethod.POST})
public String def(Locale locale, Model model) {
		return "def";
	}
	@RequestMapping(value = "/qwe", method = {RequestMethod.GET, RequestMethod.POST})
public String qwe(Locale locale, Model model) {
		return "qwe";
	}
	
}
