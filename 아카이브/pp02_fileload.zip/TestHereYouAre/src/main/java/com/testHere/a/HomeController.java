package com.testHere.a;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		return "home";
	}
	@GetMapping("/b")
	public String yourControllerMethod(Model model) {
	    // Your controller logic here

	    String nextPage = "input.jsp"; // Set the JSP location dynamically
	    String nextPages = "test";
	    model.addAttribute("data", nextPage); // Add the JSP location to the model

	    return nextPages; // Forward to a common JSP that includes the JSP specified in nextPage
	}
	@GetMapping("/a/datas")
	public String data(Model model) {
	    // Your controller logic here

	    String nextPage = "input"; // Set the JSP location dynamically
	    
	    model.addAttribute("datas", nextPage); // Add the JSP location to the model

	    return nextPage; // Forward to a common JSP that includes the JSP specified in nextPage
	}
	@GetMapping("/ppp")
	public String ppp(Model model) {
	    // Your controller logic here

	     // Set the JSP location dynamically
	    String nextPages = "ppp";
	     // Add the JSP location to the model

	    return nextPages; // Forward to a common JSP that includes the JSP specified in nextPage
	}
	@GetMapping("/qw")
	public String qw(Model model) {
	    // Your controller logic here

	     // Set the JSP location dynamically
	    String nextPages = "qqq";
	     // Add the JSP location to the model

	    return nextPages; // Forward to a common JSP that includes the JSP specified in nextPage
	}
	@GetMapping("/q")
	public String q(Model model) {
	    // Your controller logic here

	     // Set the JSP location dynamically
	    String nextPages = "uploadTest";
	     // Add the JSP location to the model

	    return nextPages; // Forward to a common JSP that includes the JSP specified in nextPage
	}
	
	 @RequestMapping(value = "/upload", method = RequestMethod.POST)
	    public String handleFileUpload(@RequestParam("file") MultipartFile file, Model model) {
	        if (!file.isEmpty()) {
	            try {
	                // Define the file path where you want to store the uploaded file
	                String filePath = "D:/save/" + file.getOriginalFilename();
	                File dest = new File(filePath);

	                // Save the uploaded file to the server
	                file.transferTo(dest);

	                // You can perform additional processing or save the file details to a database
	                // ...
	                String Address = file.getOriginalFilename();
	                
	                return showUploadedFile(model, Address); // Redirect to a success page
	            } catch (IOException e) {
	                e.printStackTrace();
	                // Handle file upload error
	            }
	        }
	        return "redirect:/error"; // Redirect to an error page
	    }
	 
	    public String showUploadedFile(Model model, String Address) {
	        // Define the file path to the uploaded file
		 
		 String filePath = "/dsave/" + Address;
	        
	        // Pass the file path to the view
	        model.addAttribute("filePath", filePath);

	        return "showFile"; // This should correspond to your view name
	    }
}
