package com.ajar.mybatis;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.datasource.init.DataSourceInitializer;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
import org.springframework.stereotype.Component;



import org.apache.ibatis.session.SqlSession;
import org.springframework.dao.DataAccessException;

@Component
public class DAO {
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Autowired
	private SqlSession sqlSession;
	
	@Value("classpath:sql/testschemahere_tb_address.sql")
   private org.springframework.core.io.Resource schemaScript;

    @Value("classpath:sql/testschemahere_tb_user.sql")
    private org.springframework.core.io.Resource dataScript;
//bean�� �ڵ������!!! �̷� �ù�
   @Bean
    public DataSourceInitializer dataSourceInitializer(DataSource dataSource) {
        DataSourceInitializer initializer = new DataSourceInitializer();
        initializer.setDataSource(dataSource);
        initializer.setDatabasePopulator(new ResourceDatabasePopulator(schemaScript, dataScript));
        return initializer;
    }
    public void executeSqlScripts() {
        try {
            dataSourceInitializer(jdbcTemplate.getDataSource()).afterPropertiesSet();
        } catch (Exception e) {
            throw new RuntimeException("Error executing SQL scripts: " + e.getMessage(), e);
        }
    }
//	public void updatep() {
//		sqlSession.update("mapper.mapp.createTables");
//	}
	public Map<Integer, User> gotAll(int idN) {
		// TODO Auto-generated method stub
		Map<Integer, User> resultMap = null;
		
		
		
		resultMap = sqlSession.selectMap("mapper.mapp.gotAll", "userId");
		return resultMap;
	}
	
	
}
