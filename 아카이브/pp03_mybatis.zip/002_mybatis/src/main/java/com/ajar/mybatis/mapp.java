package com.ajar.mybatis;

import java.util.Map;

public interface mapp { //must match the name with mapper .xml
	Map<Integer, VOS> gotAll(int idN);
}
