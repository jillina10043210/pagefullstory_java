package com.ajar.coingate.member;

import java.math.BigDecimal;
import java.util.Date;


public class MemberVO {

	private int a_m_no;
    private String a_m_title;
    private String a_m_class;
    private String a_m_content;
    private String a_m_name;
    private String a_m_type;
    private String a_m_time;
	public int getA_m_no() {
		return a_m_no;
	}
	public void setA_m_no(int a_m_no) {
		this.a_m_no = a_m_no;
	}
	public String getA_m_title() {
		return a_m_title;
	}
	public void setA_m_title(String a_m_title) {
		this.a_m_title = a_m_title;
	}
	public String getA_m_class() {
		return a_m_class;
	}
	public void setA_m_class(String a_m_class) {
		this.a_m_class = a_m_class;
	}
	public String getA_m_content() {
		return a_m_content;
	}
	public void setA_m_content(String a_m_content) {
		this.a_m_content = a_m_content;
	}
	public String getA_m_name() {
		return a_m_name;
	}
	public void setA_m_name(String a_m_name) {
		this.a_m_name = a_m_name;
	}
	public String getA_m_type() {
		return a_m_type;
	}
	public void setA_m_type(String a_m_type) {
		this.a_m_type = a_m_type;
	}
	public String getA_m_time() {
		return a_m_time;
	}
	public void setA_m_time(String a_m_time) {
		this.a_m_time = a_m_time;
	}
	
}
