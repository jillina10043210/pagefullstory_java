package com.office.library.book;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LikeBookVo {

	int l_no;
	int b_no;
	int u_m_no;
	
}
