package com.office.library.book.user;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.office.library.book.BookVo;
import com.office.library.book.CartBookVo;
import com.office.library.book.HopeBookVo;
import com.office.library.book.LikeBookVo;
import com.office.library.book.MallBookVo;
import com.office.library.book.PhotoReviewVo;
import com.office.library.book.RentalBookVo;
import com.office.library.book.ReviewBookVo;

import org.apache.ibatis.session.SqlSession;
import org.springframework.dao.DataAccessException;

@Component
public class BookDao {

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Autowired
	private SqlSession sqlSession;
	
	public List<BookVo> selectBooksBySearch(BookVo bookVo) throws DataAccessException { 
		List<BookVo> bookVos = null;
		bookVos = sqlSession.selectList("mapper.book.selectBooks", bookVo);
		return bookVos.size() > 0 ? bookVos : null;
	}	
	
	public BookVo selectBook(int b_no) {
		System.out.println("[BookDao] selectBook()");
		
		String sql = "SELECT * FROM tbl_book WHERE b_no = ?";
		
		List<BookVo> bookVos = null;
		
		try {
			
			RowMapper<BookVo> rowMapper = BeanPropertyRowMapper.newInstance(BookVo.class);
			bookVos = jdbcTemplate.query(sql, rowMapper, b_no);
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		
		return bookVos.size() > 0 ? bookVos.get(0) : null;
		
	}
	
	
	public int insertRentalBook(int b_no, int u_m_no) {
		
		String sql =  "INSERT INTO tbl_rental_book(b_no, u_m_no, rb_start_date, rb_reg_date, rb_mod_date) "
					+ "VALUES(?, ?, NOW(), NOW(), NOW())";
		
		int result = -1;
		
		try {
			
			result = jdbcTemplate.update(sql, b_no, u_m_no);
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		
		return result;
		
	}
	
	
	public void updateRentalBookAble(int b_no) {
		
		String sql =  "UPDATE tbl_book "
					+ "SET b_rental_able = 0 "
					+ "WHERE b_no = ?";
		
		try {
			
			jdbcTemplate.update(sql, b_no);
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		
	}
	
	
	public List<RentalBookVo> selectRentalBooks(int u_m_no) {
		System.out.println("[BookDao] selectRentalBooks()");
		
		String sql =  "SELECT * FROM tbl_rental_book rb "
					+ "JOIN tbl_book b "
					+ "ON rb.b_no = b.b_no "
					+ "JOIN tbl_user_member um "
					+ "ON rb.u_m_no = um.u_m_no "
					+ "WHERE rb.u_m_no = ? AND rb.rb_end_date = '1000-01-01'";
		
		List<RentalBookVo> rentalBookVos = new ArrayList<RentalBookVo>();
		
		try {
			RowMapper<RentalBookVo> rowMapper = BeanPropertyRowMapper.newInstance(RentalBookVo.class);
			rentalBookVos = jdbcTemplate.query(sql, rowMapper, u_m_no);
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		
		return rentalBookVos;
		
	}
	
	public int insertHopeBook(HopeBookVo hopeBookVo) {
		System.out.println("[BookDao] insertHopeBook()");
		
		String sql =  "INSERT INTO tbl_hope_book(u_m_no, hb_name, hb_author, hb_publisher, "
					+ "hb_publish_year, hb_reg_date, hb_mod_date, hb_result_last_date) "
					+ "VALUES(?, ?, ?, ?, ?, NOW(), NOW(), NOW())";
		
		int result = -1;
		
		try {
			
			result = jdbcTemplate.update(sql, 
											hopeBookVo.getU_m_no(), 
											hopeBookVo.getHb_name(), 
											hopeBookVo.getHb_author(), 
											hopeBookVo.getHb_publisher(), 
											hopeBookVo.getHb_publish_year());
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		
		return result;
		
	}
	
	
	public List<HopeBookVo> selectRequestHopeBooks(int u_m_no) {
		System.out.println("[BookDao] insertHopeBook()");
		
		String sql = "SELECT * FROM tbl_hope_book WHERE u_m_no = ?";
		
		List<HopeBookVo> hopeBookVos = null;
		
		try {
			
			RowMapper<HopeBookVo> rowMapper = BeanPropertyRowMapper.newInstance(HopeBookVo.class);
			hopeBookVos = jdbcTemplate.query(sql, rowMapper, u_m_no);
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		
		return hopeBookVos;
		
	}
	
	public List<RentalBookVo> selectRentalBookHistory(int u_m_no) {
		System.out.println("[BookDao] selectRentalBooks()");
		
		String sql =  "SELECT * FROM tbl_rental_book rb "
					+ "JOIN tbl_book b "
					+ "ON rb.b_no = b.b_no "
					+ "JOIN tbl_user_member um "
					+ "ON rb.u_m_no = um.u_m_no "
					+ "WHERE rb.u_m_no = ? "
					+ "ORDER BY rb.rb_reg_date DESC";
		
		List<RentalBookVo> rentalBookVos = new ArrayList<RentalBookVo>();
		
		try {
			
			RowMapper<RentalBookVo> rowMapper = BeanPropertyRowMapper.newInstance(RentalBookVo.class);
			rentalBookVos = jdbcTemplate.query(sql, rowMapper, u_m_no);
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		
		return rentalBookVos;
		
	}
	
	public int insertReviewBook(ReviewBookVo reviewBookVo) throws DataAccessException {
		int result = -1;
		result = sqlSession.insert("mapper.book.insertReviewBook", reviewBookVo);
		return result;
	}
	
	public int revCountAddBook(ReviewBookVo reviewBookVo) throws DataAccessException {
		int result = -1;
		result = sqlSession.update("mapper.book.revCountUpdate", reviewBookVo);
		return result;
	}
	
	public List<ReviewBookVo> selectReviewBooks(ReviewBookVo reviewBookVo) throws DataAccessException {
		List<ReviewBookVo> reviewBookVos = null;
		reviewBookVos = sqlSession.selectList("mapper.book.selectBnoReview", reviewBookVo);
		return reviewBookVos.size() > 0 ? reviewBookVos : null;
	}
	
	public int requestReviewBookUpdate(ReviewBookVo reviewBookVo) throws DataAccessException {
		int result = -1;
		result = sqlSession.update("mapper.book.reviewBookUpdate", reviewBookVo);
		return result;
	}
	
	public int requestReviewBookDelete(ReviewBookVo reviewBookVo) throws DataAccessException {
		int result = -1;
		result = sqlSession.delete("mapper.book.reviewBookDelete", reviewBookVo);
		return result;
	}
	
	public int revCountMinusBook(ReviewBookVo reviewBookVo) throws DataAccessException {
		int result = -1;
		result = sqlSession.update("mapper.book.revCountMinusUpdate", reviewBookVo);
		return result;
	}
	
	public int requestBookLikeCount(LikeBookVo likeBookVo) throws DataAccessException {
		int result = -1;
		result = sqlSession.selectOne("mapper.book.requestBookLikeCount", likeBookVo);
		return result;
	}
	
	public int requestBookLikeStatus(LikeBookVo likeBookVo) throws DataAccessException {
		int result = -1;
		result = sqlSession.selectOne("mapper.book.requestBookLikeStatus", likeBookVo);
		return result;
	}
	
	public int requestBookLikeInsert(LikeBookVo likeBookVo) throws DataAccessException {
		int result = -1;
		result = sqlSession.insert("mapper.book.requestBookLikeInsert", likeBookVo);
		return result;
	}
	
	public int requestBookLikeDelete(LikeBookVo likeBookVo) throws DataAccessException {
		int result = -1;
		result = sqlSession.insert("mapper.book.requestBookLikeDelete", likeBookVo);
		return result;
	}
	
	public int requestBookBnoLikeCount(int b_no, int count) throws DataAccessException {
		int result = -1;
		Map<String, Integer> map = new HashMap<>();
		map.put("b_no", b_no);
		map.put("count", count);
		result = sqlSession.update("mapper.book.requestBookBnoLikeCountUpdate", map);
		return result;
	}
	
	public int photoReviewConfirm(PhotoReviewVo photoReviewVo) throws DataAccessException {
		int result = -1;
		result = sqlSession.insert("mapper.book.photoReviewConfirm", photoReviewVo);
		return result;
	}
	
	public List<PhotoReviewVo> photoReviewAll() {
		List<PhotoReviewVo> reviewListAll = null;
		reviewListAll = sqlSession.selectList("mapper.book.photoReviewAll");
		return reviewListAll;
	}

	public List<MallBookVo> mallBookAll() {
		List<MallBookVo> reviewListAll = null;
		reviewListAll = sqlSession.selectList("mapper.book.mallBookAll");
		return reviewListAll;
	}

	public void cartIn(CartBookVo cartbookvo) {
		sqlSession.insert("mapper.book.cartIn", cartbookvo);
		
	}
	public int cartCheck(CartBookVo cartbookvo) {
		int result = 0;
		int searchResult = 0;
		searchResult = sqlSession.selectOne("mapper.book.cartCheck", cartbookvo);
		if(searchResult > 0 ) { //ã�ƺ��� �ִ�
			result = 1;
			
		}
		return result;
	}
	public void cartCheckUpdate(CartBookVo cartbookvo) {
		sqlSession.update("mapper.book.cartCheckUpdate", cartbookvo);
	}

	public List<CartBookVo> cartAll(int u_m_no) {
		List<CartBookVo> reviewListAll = null;
		reviewListAll = sqlSession.selectList("mapper.book.cartAll", u_m_no);
		return reviewListAll;
	}

	public void cartUpdateFromZero(int u_m_no, int cart_no) {
		Map<String, Object> temps = new HashMap<>();
		temps.put("u_m_no", u_m_no);
		temps.put("cart_no", cart_no);
		sqlSession.update("mapper.book.cartUpdateFromZero",  temps);
		
	}

	public List<CartBookVo> cartAllEmpty(Object tempCartBm) {
		 List<CartBookVo> reviewListAll = new ArrayList<>();

		    if (tempCartBm instanceof CartBookVo[]) {
		        CartBookVo[] cartArray = (CartBookVo[]) tempCartBm;

		        for (CartBookVo cartItem : cartArray) {
		            List<CartBookVo> reviewList1 = sqlSession.selectList("mapper.book.cartAllEmpty", cartItem);
		            reviewListAll.addAll(reviewList1);
		        }
		    }else if (tempCartBm instanceof CartBookVo) {
		     
		        List<CartBookVo> reviewList1 = sqlSession.selectList("mapper.book.cartAllEmpty", tempCartBm);
		        reviewListAll.addAll(reviewList1);
		    }
//		    } else if (tempCartBm instanceof Object[] && ((Object[]) tempCartBm).length > 0) {
//		        Object[] objectArray = (Object[]) tempCartBm;
//		        int[] intArray = new int[objectArray.length];
//
//		        for (int i = 0; i < objectArray.length; i++) {
//		            if (objectArray[i] instanceof CartBookVo) {
//		                intArray[i] = ((CartBookVo) objectArray[i]).getBm_no();
//		            } else if (objectArray[i] instanceof Integer) {
//		                intArray[i] = (Integer) objectArray[i];
//		            }
//		        }
//
//		        for (int element : intArray) {
//		            List<CartBookVo> reviewList1 = sqlSession.selectList("mapper.book.cartAllEmpty", element);
//		            reviewListAll.addAll(reviewList1);
//		        }
//		    }

		    return reviewListAll;
	}
	public List<CartBookVo> cartAllEmptys(Object tempCartBm, int u_m_no) {
	    List<CartBookVo> reviewListAll = new ArrayList<>();

	    if (tempCartBm instanceof CartBookVo[]) {
	        // If tempCartBm is an array of CartBookVo, directly update the cart
	        CartBookVo[] cartArray = (CartBookVo[]) tempCartBm;
	        for (CartBookVo cartItem : cartArray) {
	            updateCart(cartItem, u_m_no);
	            reviewListAll.add(cartItem);
	        }
	    } else if (tempCartBm instanceof Object[] && ((Object[]) tempCartBm).length > 0) {
	        // If tempCartBm is an array of integers (bm_no values), update the cart
	        Object[] objectArray = (Object[]) tempCartBm;
	        int[] intArray = new int[objectArray.length];

	        for (int i = 0; i < objectArray.length; i++) {
	            if (objectArray[i] instanceof Integer) {
	                intArray[i] = (Integer) objectArray[i];
	            }
	        }

	        for (int element : intArray) {
	            CartBookVo cartbookvo = new CartBookVo();
	            cartbookvo.setU_m_no(u_m_no);
	            cartbookvo.setBm_no(element);
	            updateCart(cartbookvo, u_m_no);
	            reviewListAll.add(cartbookvo);
	        }
	    }

	    // Retrieve the updated cart list
	    List<CartBookVo> updatedCartList = sqlSession.selectList("mapper.book.cartAll", u_m_no);
	    reviewListAll.addAll(updatedCartList);

	    return reviewListAll;
	}

	private void updateCart(CartBookVo cartbookvo, int u_m_no) {
		int searchResult = 1;
		int qty = cartbookvo.getCart_qty();
		if(u_m_no>0) {
			cartbookvo.setU_m_no(u_m_no);
			searchResult = sqlSession.selectOne("mapper.book.cartCheck", cartbookvo);
		}
	   
	  
	    if (searchResult > 0 && u_m_no >0) {
	        // The cart item already exists, update the quantity or perform other actions
	        sqlSession.update("mapper.book.cartCheckUpdate", cartbookvo);
	    } else if (searchResult ==0 && u_m_no >0) {
	        // The cart item doesn't exist, insert a new cart item
	        
	        if (qty>1) {
		    	sqlSession.insert("mapper.book.cartIn2", cartbookvo);
		    }else {
		    	sqlSession.insert("mapper.book.cartIn", cartbookvo);
		    }
	    }
	    
	}


	public void cartUpDown(CartBookVo cartbookvo, int updown) {
		Map<String, Object> temps = new HashMap<>();
		temps.put("cartbookvo", cartbookvo);
		temps.put("updown", updown);
		sqlSession.update("mapper.book.cartUpdateUpDown", temps);
		
	}

	public void cartRemovePlease(CartBookVo cartbookvo) {
		sqlSession.delete("mapper.book.cartRemovePlease",cartbookvo);
		
	}

	public void cartUpDownChange(CartBookVo cartbookvo) {
		sqlSession.update("mapper.book.cartUpdateUpDownChange", cartbookvo);
		
	}

	public void orderSetup(CartBookVo cartBook) {
		
		sqlSession.insert("mapper.book.orderSetup", cartBook);
		sqlSession.delete("mapper.book.cartRemovePlease",cartBook);
		
		
	}

	public List<CartBookVo> orderLoad(int u_m_no) {
		List<CartBookVo> newList = new ArrayList<>();
		CartBookVo cartBook = new CartBookVo();
		cartBook.setU_m_no(u_m_no);
		newList = sqlSession.selectList("mapper.book.orderLoad", cartBook);
		return newList;
	}
	
	
	
}
