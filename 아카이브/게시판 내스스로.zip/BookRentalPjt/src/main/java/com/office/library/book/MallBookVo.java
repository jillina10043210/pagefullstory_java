package com.office.library.book;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class MallBookVo {

	int bm_no;
	String bm_name;
	String bm_author;
	String bm_publisher;
	String bm_isbn;
	int bm_price;
	int bm_quantity;
	String bm_photo0;
	String bm_photo1;
	String bm_photo2;
	
}
