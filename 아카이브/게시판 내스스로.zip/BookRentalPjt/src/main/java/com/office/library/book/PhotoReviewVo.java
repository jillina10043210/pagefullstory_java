package com.office.library.book;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter

public class PhotoReviewVo {

	int pr_no;
	int u_m_no;
	String pr_name;
	String pr_author;
	String pr_publisher;
	String pr_photo0;
	String pr_photo1;
	String pr_photo2;
	
}
