package com.office.library.book.user;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.office.library.book.BookVo;
import com.office.library.book.CartBookVo;
import com.office.library.book.HopeBookVo;
import com.office.library.book.LikeBookVo;
import com.office.library.book.MallBookVo;
import com.office.library.book.PhotoReviewVo;
import com.office.library.book.RentalBookVo;
import com.office.library.book.ReviewBookVo;

@Service
public class BookService {

	@Autowired
	BookDao bookDao;

	public List<BookVo> searchBookConfirm(BookVo bookVo) {
		System.out.println("[BookService] searchBookConfirm()");
		
		return bookDao.selectBooksBySearch(bookVo);
		
	}
	
	public BookVo bookDetail(int b_no) {
		System.out.println("[BookService] bookDetail()");
		
		return bookDao.selectBook(b_no);
		
	}
	
	public int rentalBookConfirm(int b_no, int u_m_no) {
		
		int result = bookDao.insertRentalBook(b_no, u_m_no);
		if (result >= 0)
			bookDao.updateRentalBookAble(b_no);
		
		return result;
	}
	
	public List<RentalBookVo> enterBookshelf(int u_m_no) {
		System.out.println("[BookService] enterBookshelf()");
		
		return bookDao.selectRentalBooks(u_m_no);
		
	}
	
	public int requestHopeBookConfirm(HopeBookVo hopeBookVo) {
		System.out.println("[BookService] requestHopeBookConfirm()");
		
		return bookDao.insertHopeBook(hopeBookVo);
		
	}
	
	public List<HopeBookVo> listupRequestHopeBook(int u_m_no) {
		System.out.println("[BookService] listupRequestHopeBook()");
		return bookDao.selectRequestHopeBooks(u_m_no);
		
	}
	
	public List<RentalBookVo> listupRentalBookHistory(int u_m_no) {
		System.out.println("[BookService] listupRentalBookHistory()");
		
		return bookDao.selectRentalBookHistory(u_m_no);
		
	}
	
	public int requestReviewBook(ReviewBookVo reviewBookVo) {
		 return bookDao.insertReviewBook(reviewBookVo);
	}
	
	public int revCountBook(ReviewBookVo reviewBookVo) {
		return bookDao.revCountAddBook(reviewBookVo);
	}
	
	public List<ReviewBookVo> selectReviewBooks(ReviewBookVo reviewBookVo) {
		return bookDao.selectReviewBooks(reviewBookVo);
	}
	
	public int requestReviewBookModify(ReviewBookVo reviewBookVo) {
		return bookDao.requestReviewBookUpdate(reviewBookVo);
	}
	
	public int requestReviewBookDelete(ReviewBookVo reviewBookVo) {
		return bookDao.requestReviewBookDelete(reviewBookVo);
	}
	
	public int revCountMinusBook(ReviewBookVo reviewBookVo){
		return bookDao.revCountMinusBook(reviewBookVo);
	}
	
	public int requestBookLikeCount(LikeBookVo likeBookVo) {
		return bookDao.requestBookLikeCount(likeBookVo);
	}
	
	public int requestBookLikeStatus(LikeBookVo likeBookVo) {
		return bookDao.requestBookLikeStatus(likeBookVo);
	}
	
	public int requestBookLikeInsert(LikeBookVo likeBookVo){
		return bookDao.requestBookLikeInsert(likeBookVo);
	}
	
	public int requestBookLikeDelete(LikeBookVo likeBookVo){
		return bookDao.requestBookLikeDelete(likeBookVo);
	}
	
	public void requestBookBnoLikeCount(int b_no, int count) {
		bookDao.requestBookBnoLikeCount(b_no, count);
	}
	
	public int photoReviewConfirm(PhotoReviewVo photoReviewVo) {
		return bookDao.photoReviewConfirm(photoReviewVo);
	}
	
	public List<PhotoReviewVo> photoReviewAll() {
		return bookDao.photoReviewAll();
	}

	public List<MallBookVo> mallBookAll() {
		return bookDao.mallBookAll();
	}

	public void cartIn(CartBookVo cartbookvo) {
		bookDao.cartIn(cartbookvo);
		
	}

	public List<CartBookVo> cartAll(int u_m_no) {
		return bookDao.cartAll(u_m_no);
	}

	public void cartUpdateFromZero(int u_m_no, int cart_no) {
		bookDao.cartUpdateFromZero(u_m_no, cart_no);
		
	}

	public List<CartBookVo> cartAllEmpty(Object tempCartBm) {
		
		return bookDao.cartAllEmpty(tempCartBm);
	}
public List<CartBookVo> cartAllEmptys(Object tempCartBm, int u_m_no) {
		
		return bookDao.cartAllEmptys(tempCartBm, u_m_no);
	}

	public int cartCheck(CartBookVo cartbookvo) {
		// TODO Auto-generated method stub
		return bookDao.cartCheck(cartbookvo);
	}

	public void cartCheckUpdate(CartBookVo cartbookvo) {
		 bookDao.cartCheckUpdate(cartbookvo); 
		
	}

	public void cartUpDown(CartBookVo cartbookvo, int updown) {
		bookDao.cartUpDown(cartbookvo, updown);
		
	}
	public void cartUpDownChange(CartBookVo cartbookvo) {
		bookDao.cartUpDownChange(cartbookvo);
		
	}

	public void cartRemovePlease(CartBookVo cartbookvo) {
		bookDao.cartRemovePlease(cartbookvo);
		
	}

	public void orderSetup(CartBookVo cartBook) {
		bookDao.orderSetup(cartBook);
		
	}

	public List<CartBookVo> orderLoad(int u_m_no) {
		return bookDao.orderLoad(u_m_no);
	}
	
	
}
