package com.office.library.book.user;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.office.library.book.BookVo;
import com.office.library.book.CartBookVo;
import com.office.library.book.HopeBookVo;
import com.office.library.book.LikeBookVo;
import com.office.library.book.MallBookVo;
import com.office.library.book.PhotoReviewVo;
import com.office.library.book.RentalBookVo;
import com.office.library.book.ReviewBookVo;
import com.office.library.user.member.UserMemberVo;

import com.office.library.book.user.util.MultiUploadFileService;

@Controller
@RequestMapping("/book/user")
public class BookController {

	@Autowired
	BookService bookService;

	@Autowired
	MultiUploadFileService uploadFileService;

//	@RequestMapping(value = "/searchBookConfirm", method = RequestMethod.GET)
	@GetMapping("/searchBookConfirm")
	public String searchBookConfirm(BookVo bookVo, Model model) {
		String nextPage = "user/book/search_book";

		List<BookVo> bookVos = bookService.searchBookConfirm(bookVo);

		model.addAttribute("bookVos", bookVos);

		return nextPage;

	}

//	@RequestMapping(value = "/bookDetail", method = RequestMethod.GET)
	@GetMapping("/bookDetail")
	public String bookDetail(@RequestParam("b_no") int b_no, Model model) {
		System.out.println("[UserBookController] bookDetail()");

		String nextPage = "user/book/book_detail";

		BookVo bookVo = bookService.bookDetail(b_no);

		model.addAttribute("bookVo", bookVo);

		return nextPage;

	}

//	@RequestMapping(value = "/enterBookshelf", method = RequestMethod.GET)
	@GetMapping("/enterBookshelf")
	public String enterBookshelf(HttpSession session, Model model) {

		String nextPage = "user/book/bookshelf";

		UserMemberVo loginedUserMemberVo = (UserMemberVo) session.getAttribute("loginedUserMemberVo");

		List<RentalBookVo> rentalBookVos = bookService.enterBookshelf(loginedUserMemberVo.getU_m_no());

		model.addAttribute("rentalBookVos", rentalBookVos);

		return nextPage;

	}

	@GetMapping("/rentalBookConfirm")
	public String rentalBookConfirm(@RequestParam("b_no") int b_no, HttpSession session) {

		String nextPage = "user/book/rental_book_ok";

		UserMemberVo loginedUserMemberVo = (UserMemberVo) session.getAttribute("loginedUserMemberVo");

//		if (loginedUserMemberVo == null)
//			return "redirect:/user/member/loginForm";

		int result = bookService.rentalBookConfirm(b_no, loginedUserMemberVo.getU_m_no());

		if (result <= 0)
			nextPage = "user/book/rental_book_ng";

		return nextPage;

	}

	@GetMapping("/requestHopeBookForm")
	public String requestHopeBookForm() {
		System.out.println("[UserBookController] requestHopeBookForm()");

		String nextPage = "user/book/request_hope_book_form";

		return nextPage;

	}

	@GetMapping("/requestHopeBookConfirm")
	public String requestHopeBookConfirm(HopeBookVo hopeBookVo, HttpSession session) {
		System.out.println("[UserBookController] requestHopeBookConfirm()");

		String nextPage = "user/book/request_hope_book_ok";

		UserMemberVo loginedUserMemberVo = (UserMemberVo) session.getAttribute("loginedUserMemberVo");
		hopeBookVo.setU_m_no(loginedUserMemberVo.getU_m_no());

		int result = bookService.requestHopeBookConfirm(hopeBookVo);

		if (result <= 0)
			nextPage = "user/book/request_hope_book_ng";

		return nextPage;

	}

	@GetMapping("/listupRequestHopeBook")
	public String listupRequestHopeBook(HttpSession session, Model model) {
		System.out.println("[UserBookController] listupRequestHopeBook()");

		String nextPage = "user/book/list_hope_book";

		UserMemberVo loginedUserMemberVo = (UserMemberVo) session.getAttribute("loginedUserMemberVo");

		List<HopeBookVo> hopeBookVos = bookService.listupRequestHopeBook(loginedUserMemberVo.getU_m_no());

		model.addAttribute("hopeBookVos", hopeBookVos);

		return nextPage;

	}

	@GetMapping("/listupRentalBookHistory")
	public String listupRentalBookHistory(HttpSession session, Model model) {

		String nextPage = "user/book/rental_book_history";

		UserMemberVo loginedUserMemberVo = (UserMemberVo) session.getAttribute("loginedUserMemberVo");

		List<RentalBookVo> rentalBookVos = bookService.listupRentalBookHistory(loginedUserMemberVo.getU_m_no());

		model.addAttribute("rentalBookVos", rentalBookVos);

		return nextPage;

	}

	@PostMapping("/bookReviewInsert")
	public String bookReviewInsert(@RequestBody ReviewBookVo reviewBookVo, Model model) {
		String nextPage = "user/book/review_list";
		int result = bookService.requestReviewBook(reviewBookVo);
		List<ReviewBookVo> reviewBookVos = null;
		if (result > 0) {
			int cntResult = bookService.revCountBook(reviewBookVo);
			reviewBookVos = bookService.selectReviewBooks(reviewBookVo);
		}
		model.addAttribute("reviewBookVos", reviewBookVos);
		return nextPage;
	}

	@PostMapping("/bookReviewList")
	public String bookReviewList(@RequestBody ReviewBookVo reviewBookVo, Model model) {
		String nextPage = "user/book/review_list";
		List<ReviewBookVo> reviewBookVos = null;
		reviewBookVos = bookService.selectReviewBooks(reviewBookVo);
		model.addAttribute("reviewBookVos", reviewBookVos);
		return nextPage;
	}

	@PostMapping("/bookReviewModify")
	public String bookReviewModify(@RequestBody ReviewBookVo reviewBookVo, Model model) {
		String nextPage = "user/book/review_list";
		int result = bookService.requestReviewBookModify(reviewBookVo);
		List<ReviewBookVo> reviewBookVos = null;
		if (result > 0) {
			reviewBookVos = bookService.selectReviewBooks(reviewBookVo);
		}
		model.addAttribute("reviewBookVos", reviewBookVos);
		return nextPage;
	}

	@PostMapping("/bookReviewDelete")
	public String bookReviewDelete(@RequestBody ReviewBookVo reviewBookVo, Model model) {
		String nextPage = "user/book/review_list";
		int result = bookService.requestReviewBookDelete(reviewBookVo);
		List<ReviewBookVo> reviewBookVos = null;
		if (result > 0) {
			int cntResult = bookService.revCountMinusBook(reviewBookVo);
			reviewBookVos = bookService.selectReviewBooks(reviewBookVo);
		}
		model.addAttribute("reviewBookVos", reviewBookVos);
		return nextPage;
	}

	@ResponseBody
	@PostMapping("/bookReviewCount")
	public Map<String, Integer> bookReviewCount(@RequestBody ReviewBookVo reviewBookVo) {
		List<ReviewBookVo> reviewBookVos = null;
		Map<String, Integer> map = new HashMap<>();
		reviewBookVos = bookService.selectReviewBooks(reviewBookVo);
		map.put("revcnt", reviewBookVos.size());
		return map;
	}

	@ResponseBody
	@PostMapping("/bookLikeCount")
	public Map<String, Integer> bookLikeCount(@RequestBody LikeBookVo likeBookVo) {
		Map<String, Integer> map = new HashMap<>();
		int count = bookService.requestBookLikeCount(likeBookVo);
		map.put("likecnt", count);
		return map;
	}

	@ResponseBody
	@PostMapping("/bookLikeStatus")
	public Map<String, Integer> bookLikeStatus(@RequestBody LikeBookVo likeBookVo) {
		Map<String, Integer> map = new HashMap<>();
		int count = bookService.requestBookLikeCount(likeBookVo);
		int status = bookService.requestBookLikeStatus(likeBookVo);
		map.put("likecnt", count);
		map.put("status", status);
		return map;
	}

	@ResponseBody
	@PostMapping("/bookLikeInsert")
	public Map<String, Integer> bookLikeInsert(@RequestBody LikeBookVo likeBookVo) {
		Map<String, Integer> map = new HashMap<>();
		int count = 0;
		int result = bookService.requestBookLikeInsert(likeBookVo);
		if (result > 0) {
			count = bookService.requestBookLikeCount(likeBookVo);
			bookService.requestBookBnoLikeCount(likeBookVo.getB_no(), count);
		}
		map.put("likecnt", count);
		return map;
	}

	@ResponseBody
	@PostMapping("/bookLikeDelete")
	public Map<String, Integer> bookLikeDelete(@RequestBody LikeBookVo likeBookVo) {
		Map<String, Integer> map = new HashMap<>();
		int count = 0;
		int result = bookService.requestBookLikeDelete(likeBookVo);

		if (result > 0) {
			count = bookService.requestBookLikeCount(likeBookVo);
			bookService.requestBookBnoLikeCount(likeBookVo.getB_no(), count);
		}
		map.put("likecnt", count);
		return map;
	}

	@GetMapping("/bookMall")
	public String bookMall() {
		String nextPage = "user/book/book_mall";
		return nextPage;
	}

	@GetMapping("/photoReview")
	public String photoReview() {
		String nextPage = "user/book/photo_review";
		return nextPage;
	}

	@GetMapping("/cartMoving")
	public String cartMoving() {
		String nextPage = "user/book/cart";
		return nextPage;
	}

	@RequestMapping(value = "/photoReviewInsert", method = RequestMethod.POST)
	public String photoReviewInsert(@RequestPart(value = "key") PhotoReviewVo photoReviewVo,
			@RequestPart(value = "file", required = false) List<MultipartFile> files, Model model) {
		String nextPage = "user/book/photo_review_list";
		int size = files.size();
		String[] pr_photo = new String[size];
		List<Map<String, String>> savedFileNames = uploadFileService.multiUpload(files);
		for (int i = 0; i < savedFileNames.size(); i++) {
			if (savedFileNames.get(i).get("changeFile") != null) {
				pr_photo[i] = savedFileNames.get(i).get("changeFile");
				if (i == 0) {
					photoReviewVo.setPr_photo0(pr_photo[i]);
				} else if (i == 1) {
					photoReviewVo.setPr_photo1(pr_photo[i]);
				} else if (i == 2) {
					photoReviewVo.setPr_photo2(pr_photo[i]);
				}
			}
		}

		List<PhotoReviewVo> reviewListAll = null;
		int result = bookService.photoReviewConfirm(photoReviewVo);
		if (result > 0) {
			reviewListAll = bookService.photoReviewAll();
		}
		model.addAttribute("reviewListAll", reviewListAll);
		return nextPage;
	}

	@GetMapping("/photoReviewAll")
	public String photoReviewAll(Model model) {
		String nextPage = "user/book/photo_review_list";
		List<PhotoReviewVo> reviewListAll = null;
		reviewListAll = bookService.photoReviewAll();
		model.addAttribute("reviewListAll", reviewListAll);
		return nextPage;
	}

	@GetMapping("/mallBookAll")
	public String mallBookAll(Model model) {
		String nextPage = "user/book/book_mall_list";
		List<MallBookVo> reviewListAll = null;
		reviewListAll = bookService.mallBookAll();
		model.addAttribute("reviewListAll", reviewListAll);
		return nextPage;
	}

	@GetMapping("/cartAll")
	public String cartAll(Model model, HttpSession session) {
		String nextPage = "user/book/cart_list";
		UserMemberVo loginedUserMemberVo = (UserMemberVo) session.getAttribute("loginedUserMemberVo");
		int u_m_no = 0;
		if (loginedUserMemberVo != null) { // �α��� �ߴ�
			u_m_no = (int) loginedUserMemberVo.getU_m_no();
			List<CartBookVo> reviewList1 = null;
			// List<CartBookVo> reviewList2 = null;
			List<CartBookVo> reviewListAll = new ArrayList<>();
			
			// tempCartBm���� u_m_no�� ��ġ �ִ�?
			// reviewList2 = bookService.cartAllEmptys(tempCartBm, u_m_no);
			reviewList1 = bookService.cartAll(u_m_no);

			reviewListAll.addAll(reviewList1);
			// reviewListAll.addAll(reviewList2);

			model.addAttribute("reviewListAll", reviewListAll);
		} else {
			List<CartBookVo> reviewListAll = null;
			Object tempCartBm = session.getAttribute("CartBm");
			reviewListAll = bookService.cartAllEmpty(tempCartBm);
			model.addAttribute("reviewListAll", reviewListAll);
		}

		return nextPage;
	}

	@ResponseBody
	@GetMapping("/cartAlls")
	public List<CartBookVo> cartAlls(HttpSession session) {

		UserMemberVo loginedUserMemberVo = (UserMemberVo) session.getAttribute("loginedUserMemberVo");
		int u_m_no = 0;
		if (loginedUserMemberVo != null) {
			u_m_no = (int) loginedUserMemberVo.getU_m_no();
			List<CartBookVo> reviewList1 = null;
			// List<CartBookVo> reviewList2 = null;
			List<CartBookVo> reviewListAll = new ArrayList<>();
			Object tempCartBm = session.getAttribute("CartBm");

			reviewList1 = bookService.cartAllEmptys(tempCartBm, u_m_no);
			reviewListAll.addAll(reviewList1);
			// reviewListAll.addAll(reviewList2);

			return reviewListAll;
		} else {
			List<CartBookVo> reviewListAll = null;
			Object tempCartBm = session.getAttribute("CartBm");
			reviewListAll = bookService.cartAllEmpty(tempCartBm);
			return reviewListAll;
		}

	}

	@ResponseBody
	@RequestMapping(value = "/cartIn/{attr}", method = { RequestMethod.GET, RequestMethod.POST })
	public void cartIn(Model model, @PathVariable("attr") int bm_no, HttpSession session) {

		UserMemberVo loginedUserMemberVo = (UserMemberVo) session.getAttribute("loginedUserMemberVo");
		Object tempCartBm = session.getAttribute("CartBm");

		CartBookVo cartbookvo = new CartBookVo();
		int u_m_no = 0;
		int tempCart_qty = 1;
		if (loginedUserMemberVo != null) {// �α��� ������
			u_m_no = (int) loginedUserMemberVo.getU_m_no();
			cartbookvo.setU_m_no(u_m_no);
			cartbookvo.setBm_no(bm_no);
			int result = bookService.cartCheck(cartbookvo);
			if (result > 0) { // ã���� �־�
				bookService.cartCheckUpdate(cartbookvo);
			} else { // ã���� ����
				bookService.cartIn(cartbookvo);
			}

		} else {// �� ���� ������ �̷� �ᵵ ������ ���ٿ� ;D
			if (tempCartBm != null) {
				// �� bm_no �����ִ� üũ
				if (tempCartBm instanceof CartBookVo[]) {

					CartBookVo[] array = (CartBookVo[]) tempCartBm;
					boolean containsBmNo = false;
					for (CartBookVo element : array) {
						if (element != null && element.getBm_no()==bm_no) {
							containsBmNo = true;
							break; // �ִܴ� session��
						}
					}

					if (!containsBmNo) { // session�� ���ܴ�.
						CartBookVo newItem = new CartBookVo();
						newItem.setBm_no(bm_no);
						newItem.setCart_qty(tempCart_qty);
						CartBookVo[] newArray = Arrays.copyOf(array, array.length + 1);
						newArray[array.length] = newItem;
						session.setAttribute("CartBm", newArray);
					}

				}
			} else {

				CartBookVo[] newArray = new CartBookVo[] {new CartBookVo(bm_no, tempCart_qty) };

				session.setAttribute("CartBm", newArray);
			}

		}

	}

	@ResponseBody
	@RequestMapping(value = "/cartUpAndDown/{updown}", method = { RequestMethod.GET, RequestMethod.POST })
	public void cartUpAndDown(Model model, @RequestBody CartBookVo cartbookvo, @PathVariable("updown") int updown,
			HttpSession session) {
		
		int checkLogin = cartbookvo.getU_m_no();
		int bm_no = cartbookvo.getBm_no();
		int cart_qty = cartbookvo.getCart_qty();
		
		Object tempCartBm = session.getAttribute("CartBm");
		if (checkLogin > 0) {
			bookService.cartUpDown(cartbookvo, updown);
		} else {
			
			 if (tempCartBm instanceof CartBookVo[]) {
				 
		            CartBookVo[] cartArray = (CartBookVo[]) tempCartBm;

		            // Find the CartBookVo with the specified bm_no
		            for (CartBookVo cartItem : cartArray) {
		            
		                if (cartItem != null && cartItem.getBm_no() == bm_no) {
		            
		                    // Update the cart_qty to the new value
		                    cartItem.setCart_qty(cart_qty);
		                    break;
		                }
		            }
		            
		            
		            
		            // Update the session attribute
		            session.setAttribute("CartBm", cartArray);
		        }

		}

	}

	@ResponseBody
	@RequestMapping(value = "/cartUpAndDownChange", method = { RequestMethod.GET, RequestMethod.POST })
	public void cartUpAndDownChange(Model model, @RequestBody CartBookVo cartbookvo, HttpSession session) {
		int checkLogin = cartbookvo.getU_m_no();
		int bm_no = cartbookvo.getBm_no();
		int cart_qty = cartbookvo.getCart_qty();
		Object tempCartBm = session.getAttribute("CartBm");
		if (checkLogin > 0) {
			bookService.cartUpDownChange(cartbookvo);
		} else {
			
			 if (tempCartBm instanceof CartBookVo[]) {
				 
		            CartBookVo[] cartArray = (CartBookVo[]) tempCartBm;

		            // Find the CartBookVo with the specified bm_no
		            for (CartBookVo cartItem : cartArray) {
		            
		                if (cartItem != null && cartItem.getBm_no() == bm_no) {
		                	
		                    // Update the cart_qty to the new value
		                    cartItem.setCart_qty(cart_qty);
		                    break;
		                }
		            }
		            
		            
		            
		            // Update the session attribute
		            session.setAttribute("CartBm", cartArray);
		        }

		}

	}

	@ResponseBody
	@RequestMapping(value = "/cartDeleteThis", method = { RequestMethod.GET, RequestMethod.POST })
	public void cartDeleteThis(Model model, @RequestBody CartBookVo cartbookvo, HttpSession session) {
	    int checkLogin = cartbookvo.getU_m_no();
	    int bm_no = cartbookvo.getBm_no();
	    
	    if (checkLogin > 0) {
	        bookService.cartRemovePlease(cartbookvo);
	    } else {
	        Object tempCartBm = session.getAttribute("CartBm");
	        if (tempCartBm != null) {
	            if (tempCartBm instanceof CartBookVo[]) {
	                // If the session attribute is an array of CartBookVo objects
	                CartBookVo[] cartArray = (CartBookVo[]) tempCartBm;
	                
	                // Find the index of the CartBookVo object with the specified bm_no
	                int indexToRemove = -1;
	                for (int i = 0; i < cartArray.length; i++) {
	                    if (cartArray[i] != null && cartArray[i].getBm_no() == bm_no) {
	                        indexToRemove = i;
	                        break;
	                    }
	                }

	                if (indexToRemove != -1) {
	                    // Remove the object at the found index
	                    CartBookVo[] newArray = new CartBookVo[cartArray.length - 1];
	                    System.arraycopy(cartArray, 0, newArray, 0, indexToRemove);
	                    System.arraycopy(cartArray, indexToRemove + 1, newArray, indexToRemove,
	                            cartArray.length - indexToRemove - 1);

	                    session.setAttribute("CartBm", newArray);
	                }
	            } else if (tempCartBm instanceof Object[]) {
	                // If the session attribute is an array of integers (bm_no values)
	                Object[] cartBmArray = (Object[]) tempCartBm;

	                // Find the index of the object with the specified bm_no
	                int indexToRemove = -1;
	                for (int i = 0; i < cartBmArray.length; i++) {
	                    if (cartBmArray[i] != null && cartBmArray[i] instanceof Integer
	                            && ((Integer) cartBmArray[i]) == bm_no) {
	                        indexToRemove = i;
	                        break;
	                    }
	                }

	                if (indexToRemove != -1) {
	                    // Remove the object at the found index
	                    Object[] newArray = new Object[cartBmArray.length - 1];
	                    System.arraycopy(cartBmArray, 0, newArray, 0, indexToRemove);
	                    System.arraycopy(cartBmArray, indexToRemove + 1, newArray, indexToRemove,
	                            cartBmArray.length - indexToRemove - 1);

	                    session.setAttribute("CartBm", newArray);
	                }
	            }
	        }
	    }
	}


	@ResponseBody
	@RequestMapping(value = "/cartUpdateFromZero", method = { RequestMethod.GET, RequestMethod.POST })
	public void cartUpdateFromZero(@RequestParam("u_m_no") int u_m_no, @RequestParam("bm_no") int bm_no,
			HttpSession session) {
		CartBookVo cartbookvo = new CartBookVo();
		cartbookvo.setU_m_no(u_m_no);
		cartbookvo.setBm_no(bm_no);

		session.removeAttribute("CartBm");

	}
	
	//@RequestMapping(value = "/callPurchase", method = { RequestMethod.GET, RequestMethod.POST })
	@PostMapping("/callPurchase")
	public ResponseEntity<String> callPurchase(Model model, @RequestBody List<CartBookVo> cartbooklist, HttpSession session) {
		 try {
		int u_m_no = 0; 
		for (CartBookVo cartBook : cartbooklist) {
	            // Access properties using getters
			u_m_no = cartBook.getU_m_no();
			bookService.orderSetup(cartBook);
	            
	        }
		String nextPage = "/user/book/order_done";
		List<CartBookVo> orderList = null;
		orderList = bookService.orderLoad(u_m_no);
		model.addAttribute("orderList", orderList);
		 return new ResponseEntity<>("/book/user/order_done", HttpStatus.OK);
		 }
		 catch(Exception e) {
		        return new ResponseEntity<>("Error placing order", HttpStatus.INTERNAL_SERVER_ERROR);
		    }
	}
	@GetMapping("/order_done")
	public String order_done(Model model, HttpSession session) {
		String nextPage = "/user/book/order_done";
		List<CartBookVo> orderList = null;
		UserMemberVo loginedUserMemberVo = (UserMemberVo) session.getAttribute("loginedUserMemberVo");
		int u_m_no = (int) loginedUserMemberVo.getU_m_no();
		orderList = bookService.orderLoad(u_m_no);
		model.addAttribute("orderList", orderList);
		return nextPage;
	}

}
