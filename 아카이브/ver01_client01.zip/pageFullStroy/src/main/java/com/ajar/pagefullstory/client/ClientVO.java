package com.ajar.pagefullstory.client;

public class ClientVO {

}
